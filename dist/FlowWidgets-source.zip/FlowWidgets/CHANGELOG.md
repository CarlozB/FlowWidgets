# Cambios

## 1.2.0 · Widgets adaptativos

- Motor de perfiles dp compartido por los ocho proveedores, variantes RemoteViews y reconstrucción al redimensionar.
- Contenido progresivo: zonas horarias, calendario/agenda, detalles reales de batería, pronóstico diario, progreso y cola compatible, collages, listas marcables y hasta dieciséis accesos.
- Editor con once proporciones simuladas y personalización Soft Light Glass con caché acotada.
- Persistencia compatible con versiones anteriores y actualización transaccional de tareas por instancia.
- Pruebas de perfiles, presupuesto, reaplicación al reducir y aislamiento de datos; documentación de APIs y límites físicos.


## 1.1.0

- Composiciones de escritorio propias por tipo, inspiradas en la claridad visual de iOS.
- Esfera y agujas originales del reloj, operadas por AnalogClock nativo; modo digital conservado.
- Sol, nubes, lluvia, nieve, niebla y tormentas dibujados desde código; caché con código meteorológico actual.
- Indicadores de batería, notas con cabecera, calendario adaptable y accesos con iconos prominentes.
- Portada multimedia dominante y controles vectoriales con acciones reales.
- Vistas previas Compose y del selector generadas por el motor de escritorio.
- Redibujado tras actualizar el APK; layouts nuevos que preservan los IDs antiguos para evitar reutilizar la jerarquía anterior.
- 20 pruebas locales: persistencia, RemoteViews y renderización nativa en siete proporciones.

## 1.0.0

- Proyecto Android Kotlin/Compose con catálogo adaptable y editor por instancia.
- Ocho proveedores de widgets, preferencias DataStore y cuatro familias visuales.
- Integraciones oficiales de batería, calendario, fotos, accesos y sesiones multimedia.
- Clima Open-Meteo, caché offline y actualizaciones periódicas de bajo consumo.
- Pruebas de almacenamiento y RemoteViews, análisis estático y recorridos Compose.

Los resultados ejecutados y las limitaciones de dispositivo se registran en `docs/VALIDATION.md`.
